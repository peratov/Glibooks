# 📚 Glibooks — Personalised Children's Books

A full-stack e-commerce platform for creating personalised storybooks starring your child. Built with **React + Vite** (frontend) and **Express.js** (backend).

## 🎯 Features

- **Book catalogue** with category filtering and search
- **Photo upload** — child's photo is embedded into the book cover preview
- **Book personalisation** — custom child name, age, cover type (hardcover/softcover)
- **Sticker add-ons**
- **Shopping cart** with quantity management and coupon codes
- **Checkout flow** with shipping address collection
- **User authentication** (JWT-based)
- **My Books** — saved personalised book configurations
- **Order history**
- **Stripe-ready** payment integration (runs in demo mode without a key)

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, React Router v6, Vite |
| Backend | Express.js (ESM), Multer, JWT, bcryptjs |
| Payments | Stripe (optional) |
| Fonts | Fraunces + Plus Jakarta Sans |
| Database | In-memory (swap for PostgreSQL/MongoDB in production) |

## 🚀 Quick Start

### 1. Clone and install

```bash
git clone <your-repo-url>
cd glibooks
npm run install:all
```

### 2. Configure environment

```bash
cp backend/.env.example backend/.env
# Edit backend/.env with your values
```

### 3. Run in development

```bash
# Terminal 1 — backend
npm run dev:backend

# Terminal 2 — frontend
npm run dev:frontend
```

- Frontend: http://localhost:5173
- Backend API: http://localhost:4000

### Demo credentials
- Email: `demo@glibooks.com`
- Password: `password`

### Demo coupon codes
- `EXTRA20` — 20% off 2+ books
- `FIRST10` — 10% off
- `SAVE5` — £5 off

## 📁 Project Structure

```
glibooks/
├── backend/
│   ├── src/
│   │   ├── index.js          # Express app entry
│   │   ├── db.js             # In-memory data store + seed data
│   │   ├── middleware/
│   │   │   └── auth.js       # JWT middleware
│   │   └── routes/
│   │       ├── auth.js       # Register, login, /me
│   │       ├── books.js      # Book catalogue + My Books
│   │       ├── cart.js       # Cart CRUD + coupons
│   │       ├── orders.js     # Order creation + history
│   │       ├── upload.js     # Photo upload (Multer)
│   │       └── payment.js    # Stripe payment intents
│   ├── uploads/              # Uploaded child photos
│   └── package.json
│
└── frontend/
    ├── src/
    │   ├── App.jsx            # Routing
    │   ├── api.js             # API client
    │   ├── context/
    │   │   ├── AuthContext.jsx
    │   │   └── CartContext.jsx
    │   ├── components/
    │   │   ├── Navbar.jsx
    │   │   ├── Footer.jsx
    │   │   └── BookCard.jsx
    │   └── pages/
    │       ├── Home.jsx
    │       ├── Books.jsx
    │       ├── BookDetail.jsx  # Personalisation flow
    │       ├── Cart.jsx
    │       ├── Checkout.jsx
    │       ├── OrderConfirmation.jsx
    │       ├── MyBooks.jsx
    │       ├── Auth.jsx
    │       └── Other.jsx       # Orders, Stickers, Support
    └── package.json
```

## 🔐 Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `PORT` | Backend port | `4000` |
| `FRONTEND_URL` | CORS origin | `http://localhost:5173` |
| `JWT_SECRET` | JWT signing secret | Change in production! |
| `STRIPE_SECRET_KEY` | Stripe secret key | None (demo mode) |
| `STRIPE_WEBHOOK_SECRET` | Stripe webhook | None |

## 🗃 Moving to a Real Database

The `backend/src/db.js` file exports an in-memory `db` object. To connect to PostgreSQL or MongoDB:

1. Install your ORM (e.g., `prisma`, `mongoose`)
2. Replace the `db` import in each route file with your ORM queries
3. Add `DATABASE_URL` to your `.env`

## 💳 Enabling Stripe Payments

1. Add `STRIPE_SECRET_KEY=sk_live_...` to `backend/.env`
2. Add your Stripe **publishable key** to `frontend/src/.env` as `VITE_STRIPE_PK`
3. Integrate `@stripe/react-stripe-js` `Elements` and `PaymentElement` in `Checkout.jsx`
4. The payment intent endpoint at `/api/payment/create-intent` is already implemented

## 🚢 Deploying to Production

### Backend
- Deploy to Railway, Render, or Fly.io
- Set all environment variables
- Replace in-memory DB with a real database

### Frontend
- Run `npm run build:frontend` → outputs to `frontend/dist/`
- Deploy to Vercel, Netlify, or Cloudflare Pages
- Set `VITE_API_URL` if your backend is on a different domain

## 📝 Importing into Google AI Studio

1. Push this project to GitHub
2. In Google AI Studio, use **Import from GitHub**
3. The project is self-contained — no secrets needed to browse the code
4. Set your environment variables in the AI Studio project settings

---

Built with ❤️ for magical childhood memories.
